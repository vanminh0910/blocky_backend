# blocky_backend
Backend for blocky

# dynamodb local
sls dynamodb install
sls dynamodb migrate
sls dynamodb seed
sls dynamodb start --seed users